"""
4. Una empresa tiene 500 almacenes. Cada almacén debe
reportar el nombre y 5 registros c/u, contiene el tipo de articulo
y el número de unidades vendidas de ese artículo.

Haga un programa en Python para determinar cuál fue el
almacén que mas vendió, cual fue el articulo más vendido de
ese almacén y cual el más vendido en general.
"""
#Almacenes y productos
almacenes = []
producto1 = []
producto2 = []
producto3 = []
producto4 = []
producto5 = []
program = True
#para los valores
def introduce ():
    print("Bienvenido a la calculadora de ventas")
    vPT1 = input("Ventas del producto #1")
    producto1.append([vPT1])
    vPT2 = input("Ventas del producto #2")
    producto2.append([vPT2])
    vPT3 = input("Ventas del producto #3")
    producto3.append([vPT3])
    vPT4 = input("Ventas del producto #4")
    producto4.append([vPT4])
    vPT5 = input("Ventas del producto #5")
    producto5.append([vPT5])
#bucle del programa
while program==True:
    nombre = input("Ingrese el nombre del almacén: ")
    if nombre== 'exit':
        program = False
    else:
        almacenes.append([nombre])
    introduce()
    


    
    